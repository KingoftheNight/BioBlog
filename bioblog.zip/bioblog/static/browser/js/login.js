function signincheck(){
    var password = document.getElementById("login_pwd").value;
    if (password.length<6){
        document.getElementById("login").disabled = "disabled";
        document.getElementById("pwdinTip").style.display = "block";                
    }
    else {
        document.getElementById("login").disabled = "";
        document.getElementById("pwdinTip").style.display = "none";  
    }
}
function signupcheck(){
    var password = document.getElementById("password").value;
    if (password.length<6){
        document.getElementById("register").disabled = "disabled";
        document.getElementById("pwdupTip").style.display = "block";                
    }
    else {
        document.getElementById("register").disabled = "";
        document.getElementById("pwdupTip").style.display = "none";  
    }
}
function compairation(){
    var password = document.getElementById("password").value;
    var confword = document.getElementById("confword").value;
    if (password!=confword){
        document.getElementById("register").disabled = "disabled";
        document.getElementById("macthTip").style.display = "block";
    }
    else {
        document.getElementById("register").disabled = "";
        document.getElementById("macthTip").style.display = "none";
    }
}
function checkemail(){
    var email = document.getElementById("email").value;
    var myReg=/^[a-zA-Z0-9_-]+@([a-zA-Z0-9]+\.)+(com|cn|net|org)$/;
    if(myReg.test(email)){
        document.getElementById("register").disabled = "";
        document.getElementById("emailTip").style.display = "none";
    }
    else {
        document.getElementById("register").disabled = "disabled";
        document.getElementById("emailTip").style.display = "block";
    }
}